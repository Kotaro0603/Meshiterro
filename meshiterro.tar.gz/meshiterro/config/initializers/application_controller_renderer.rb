# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f5098ed43c12a1508439b35a898d0cf67542af27c57bc285760c72efe080b87bf91357f35bd9214c213628e25f4f17a9d62c7a07088574ec78286f844fd2c626'
